This repository contains the terraform modules for Azure infrastructure which can be consumed by multiple teams in Geneva.
we are still adding the modules for azure resources.
Reach out to us if you want a terraform module for the resource which is not already created.