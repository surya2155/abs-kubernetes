# Terraform script for Azure Redis Cache service

Define the variables before running terraform script

Export the azure credentials follow below steps.

For Windows, this can just be done with ```SET``` and for linux it can be done with ```export```.

Here is a sample for Linux / Git Bash terminal:

```ps1
SET ARM_CLIENT_ID="xxxxxxxxxxxxxxxxxxxxxxxxxx"
SET ARM_CLIENT_CERTIFICATE_PATH="path/terraform.pfx"
SET ARM_SUBSCRIPTION_ID="xxxxxxxxxxxxxxxxxxxxxxxxxx"
SET ARM_TENANT_ID="xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```
Here is a sample for Windows:
```bash
export ARM_CLIENT_ID="xxxxxxxxxxxxxxxxxxxxx"
export ARM_CLIENT_CERTIFICATE_PATH="path/terraform.pfx"
export ARM_SUBSCRIPTION_ID="xxxxxxxxxxxxxxxxxx"
export ARM_TENANT_ID="xxxxxxxxxxxxxxxxxxxxxxxx"
```