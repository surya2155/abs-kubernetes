# geneva-utilities-acr-purge
 Azure Container Registry ACR image purge (Clearup)


# Terraform script running steps
Use linux based OS with Docker and Terraform installed.
Clone the repository 

Set variables in variables.tf file.
Set Azure Account information.

Run below commends
```bash
terraform init
terraform plan
terraform apply
```



[reffer official doc](https://docs.microsoft.com/en-us/azure/container-registry/container-registry-auto-purge) 

utomated scheduled ACR purge process.

## Azure Cli Bash commends
### login to Az Cli
```az cli
az login # use azure credentials to login
```

### get the current default subscription using show
```az cli
az account list --output table
```

### change the active subscription using the subscription name
```az cli
az account set --subscription "subscription name" # ACR subscription
```

### login to Azure container registry
```az cli
az acr login –name “registary_name”
```

---
## Command for purge ACR images.
#### filter *:.* will considered all the Repository & images from the registry
#### to run particular registry change first * with registry name.
```az cli
PURGE_CMD="acr purge --filter "*:.*" \
--untagged \
--ago 30d \ # 30d = older then 30 days image
--keep 10 \ # keep 10 images even older then 30 days.
--dry-run " # dry run while implementing remove this line.
```

## Schedule task for purge
#### replace "registry-name with "container registry name"
```az cli
az acr task create --name acr-image-purge \
--cmd "$PURGE_CMD" \
--schedule "0 0 * * 1" \ # cron job schedule format. “At 00:00 on Monday.”
--registry registry-name \
--context /dev/null
```
---