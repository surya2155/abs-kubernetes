# AKS setup for Data analytics 
















## Running Terraform
* Set system environment variables


# Generating Key file for Terraform Azure authentication [refer](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/service_principal_client_certificate)


```bash
openssl req -newkey rsa:4096 -nodes -keyout "terraform.key" -out "terraform.csr" \
openssl x509 -signkey "terraform.key" -in "terraform.csr" -req -days 365 -out "terraform.crt" \
openssl pkcs12 -export -out "terraform.pfx" -inkey "terraform.key" -in "terraform.crt"
```
Once Key file ready, go to azure portal create app registration and service principle with the name terraform.
navigate to Azure access control add required access to terraform user.




### System Environment Variables

You'll need to set the following in your system for azure login

* ARM_SUBSCRIPTION_ID
* ARM_CLIENT_ID
* ARM_TENANT_ID
* ARM_CLIENT_CERTIFICATE_PATH

For Windows, this can just be done with ```SET``` and for linux it can be done with ```export```.

Here is a sample for Linux / Git bash terminal:

```ps1 
SET ARM_CLIENT_ID="37a67ea4-ecbd-4797-9b7b-1275eab5d615"
SET ARM_CLIENT_CERTIFICATE_PATH="C:\Users\Rajkumar.Aute\.ssh\gnva-acm-pub-sbx-kv001-clientcert-20221116.pfx"
SET ARM_SUBSCRIPTION_ID="a2bd2bf9-3b7e-457b-9828-0a81f1ffb88e"
SET ARM_TENANT_ID="db1e96a8-a3da-442a-930b-235cac24cd5c"
```
Here is a sample for Windows:
```bash
export ARM_CLIENT_ID="37a67ea4-ecbd-4797-9b7b-1275eab5d615"
export ARM_CLIENT_CERTIFICATE_PATH="C:\Users\Rajkumar.Aute\.ssh\gnva-acm-pub-sbx-kv001-clientcert-20221116.pfx"
export ARM_SUBSCRIPTION_ID="a2bd2bf9-3b7e-457b-9828-0a81f1ffb88e"
export ARM_TENANT_ID="db1e96a8-a3da-442a-930b-235cac24cd5c"
```


Outputs:
aks_cluster_id = "/subscriptions/a2bd2bf9-3b7e-457b-9828-0a81f1ffb88e/resourceGroups/geneva_aks_rg-dev/providers/Microsoft.ContainerService/managedClusters/geneva-aks-cluster-dev"
aks_cluster_name = "geneva-aks-cluster-dev"
aks_cluster_version = "1.24.6"
aks_latest_version = "1.24.6"
location = "northeurope"
resource_group_id = "/subscriptions/a2bd2bf9-3b7e-457b-9828-0a81f1ffb88e/resourceGroups/geneva_aks_rg-dev"
resource_group_name = "geneva_aks_rg-dev"



# login kubectl 
az account set --subscription a2bd2bf9-3b7e-457b-9828-0a81f1ffb88e
az aks get-credentials --resource-group geneva_aks_rg-dev --name geneva-aks-cluster-dev